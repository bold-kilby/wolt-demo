package com.example.wolt.util

fun List<String>.writeOnSeparateLines(): String = joinToString("\n")